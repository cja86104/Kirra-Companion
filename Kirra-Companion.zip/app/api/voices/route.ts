import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import {
  OPENAI_VOICES,
  hasVoiceAccess,
  getVoiceLimitForTier,
  type OpenAIVoiceId,
} from '@/lib/tts/openai-tts';
import type { Profile } from '@/types/database';

/**
 * Voice option returned to client
 */
interface VoiceOption {
  voice_id: string;
  name: string;
  description: string;
  gender: 'male' | 'female' | 'neutral';
  personality: string;
  available: boolean;
  preview_text: string;
}

/**
 * GET /api/voices
 * 
 * Returns list of available OpenAI TTS voices for the user's tier.
 * All voices are available to all paid tiers (OpenAI pricing makes this affordable).
 */
export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient();

    // Verify user is authenticated
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    // Get user profile for tier
    const { data: profileData } = await supabase
      .from('profiles')
      .select('subscription_tier, voice_characters_used')
      .eq('id', user.id)
      .single();

    const profile = profileData as Pick<Profile, 'subscription_tier' | 'voice_characters_used'> | null;
    const tier = profile?.subscription_tier || 'free';
    const hasAccess = hasVoiceAccess(tier);

    // Build voice options list
    const voiceOptions: VoiceOption[] = Object.entries(OPENAI_VOICES).map(([id, voice]) => ({
      voice_id: id,
      name: voice.name,
      description: voice.description,
      gender: voice.gender,
      personality: voice.personality,
      available: hasAccess, // All voices available if user has access
      preview_text: voice.previewText,
    }));

    // Calculate usage stats
    const characterLimit = getVoiceLimitForTier(tier);
    const charactersUsed = profile?.voice_characters_used || 0;

    return NextResponse.json({
      voices: voiceOptions,
      tier,
      has_voice_access: hasAccess,
      available_count: hasAccess ? voiceOptions.length : 0,
      total_count: voiceOptions.length,
      provider: 'openai',
      usage: {
        characters_used: charactersUsed,
        characters_limit: characterLimit,
        characters_remaining: Math.max(0, characterLimit - charactersUsed),
        percent_used: characterLimit > 0 ? Math.round((charactersUsed / characterLimit) * 100) : 0,
      },
      upgrade_message: !hasAccess 
        ? 'Upgrade to a paid plan to unlock voice features for your companions.'
        : null,
    });

  } catch (error) {
    console.error('Voices API error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch voices' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/voices
 * 
 * Validate a voice configuration before saving.
 */
export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient();

    // Verify user is authenticated
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { voiceId, speed } = body;

    // Validate voice ID
    if (!voiceId || !OPENAI_VOICES[voiceId as OpenAIVoiceId]) {
      return NextResponse.json(
        { 
          error: 'Invalid voice ID',
          valid_ids: Object.keys(OPENAI_VOICES),
        },
        { status: 400 }
      );
    }

    // Validate speed if provided
    if (speed !== undefined) {
      if (typeof speed !== 'number' || speed < 0.25 || speed > 4.0) {
        return NextResponse.json(
          { 
            error: 'Speed must be a number between 0.25 and 4.0',
            received: speed,
          },
          { status: 400 }
        );
      }
    }

    // Get user tier
    const { data: profileData } = await supabase
      .from('profiles')
      .select('subscription_tier')
      .eq('id', user.id)
      .single();

    const profile = profileData as Pick<Profile, 'subscription_tier'> | null;
    const tier = profile?.subscription_tier || 'free';

    if (!hasVoiceAccess(tier)) {
      return NextResponse.json(
        { 
          error: 'Voice features require a paid subscription',
          current_tier: tier,
        },
        { status: 403 }
      );
    }

    // Return validated configuration
    const voiceConfig = {
      provider: 'openai' as const,
      voiceId,
      model: 'tts-1' as const,
      speed: speed ?? 1.0,
    };

    const voice = OPENAI_VOICES[voiceId as OpenAIVoiceId];

    return NextResponse.json({
      valid: true,
      voice_config: voiceConfig,
      voice_details: {
        name: voice.name,
        description: voice.description,
        gender: voice.gender,
        personality: voice.personality,
      },
    });

  } catch (error) {
    console.error('Voice validation error:', error);
    return NextResponse.json(
      { error: 'Failed to validate voice configuration' },
      { status: 500 }
    );
  }
}
