/**
 * Kirra Companion - Database Types
 * 
 * This file contains all TypeScript types for the Supabase database schema.
 * Generated based on the database migrations and used throughout the application.
 * 
 * IMPORTANT: This file must stay in sync with the database schema.
 * Run `npm run db:generate` to regenerate from Supabase after schema changes.
 */

// ============================================================================
// ENUMS
// ============================================================================

export type SubscriptionTier = 'free' | 'basic' | 'pro' | 'ultimate';
export type SubscriptionStatus = 'active' | 'canceled' | 'past_due' | 'trialing' | 'incomplete';
export type AgeTier = 'blocked' | 'minor' | 'adult';
export type RelationshipType = 'friend' | 'mentor' | 'romantic' | 'family' | 'custom';
export type MessageRole = 'user' | 'companion' | 'system';
export type ContentType = 'text' | 'image' | 'audio' | 'file';
export type CrisisType = 'self_harm' | 'harm_to_others' | 'abuse' | 'none';
export type CrisisSeverity = 'low' | 'medium' | 'high' | 'critical';
export type EventType = 
  | 'activity_completed'
  | 'mood_shift'
  | 'interest_developed'
  | 'milestone_reached'
  | 'memory_formed'
  | 'journal_entry'
  | 'social_interaction'
  | 'discovery'
  | 'achievement'
  | 'reflection'
  | 'dream'
  | 'goal_set'
  | 'goal_achieved'
  | 'conversation_highlight';

// ============================================================================
// JSON TYPES (stored as JSONB in database)
// ============================================================================

export interface MoodState {
  primary: string;
  secondary?: string | null;
  intensity: number;
  lastUpdated?: string | null;
}

export interface PersonalityBase {
  openness: number;
  conscientiousness: number;
  extraversion: number;
  agreeableness: number;
  neuroticism: number;
  humor?: number;
  empathy?: number;
  curiosity?: number;
  playfulness?: number;
  assertiveness?: number;
}

export interface CompanionNeeds {
  social: number;
  energy: number;
  fun: number;
  comfort: number;
  affection: number;
  intellectual: number;
  creativity: number;
  lastUpdated: string;
  lastInteraction: string;
}

export interface VoiceConfig {
  provider: 'elevenlabs' | 'openai';
  voiceId: string | null;
  stability: number;
  similarityBoost: number;
  style: number;
  speakingRate: number;
}

export interface Avatar3DConfig {
  model: string;
  skinTone: string;
  hairColor: string;
  hairStyle: string;
  eyeColor: string;
  expression: string;
  outfit: string;
  accessories: string[];
}

export interface CommunicationDialect {
  favoriteExpressions: string[];
  vocabularyLevel: 'simple' | 'moderate' | 'advanced' | 'adaptive';
  sentenceComplexity: number;
  emojiUsage: number;
  formalityLevel: number;
  uniquePhrases: string[];
  avoidedWords: string[];
  speechPatterns: string[];
}

export interface EmotionalPatterns {
  triggers: Record<string, string[]>;
  recoveryTime: number;
  expressionStyle: string;
  emotionalRange: number;
}

export interface CoreTraits {
  values: string[];
  fears: string[];
  dreams: string[];
  strengths: string[];
  weaknesses: string[];
}

export interface BehavioralProfile {
  flaggedPatterns: string[];
  confidence: number;
  lastAnalyzed: string;
}

// ============================================================================
// PROFILES TABLE
// ============================================================================

export interface Profile {
  id: string;
  email: string;
  full_name: string | null;
  avatar_url: string | null;
  date_of_birth: string | null;
  age_tier: AgeTier;
  is_minor_flagged: boolean;
  minor_flagged_at: string | null;
  minor_flag_reason: string | null;
  behavioral_profile: BehavioralProfile | null;
  subscription_tier: SubscriptionTier;
  subscription_status: SubscriptionStatus;
  stripe_customer_id: string | null;
  stripe_subscription_id: string | null;
  subscription_period_end: string | null;
  is_admin: boolean;
  messages_today: number;
  messages_reset_at: string;
  preferences: Record<string, unknown> | null;
  timezone: string | null;
  created_at: string;
  updated_at: string;
}

export interface ProfileInsert {
  id: string;
  email: string;
  full_name?: string | null;
  avatar_url?: string | null;
  date_of_birth?: string | null;
  age_tier?: AgeTier;
  is_minor_flagged?: boolean;
  minor_flagged_at?: string | null;
  minor_flag_reason?: string | null;
  behavioral_profile?: BehavioralProfile | null;
  subscription_tier?: SubscriptionTier;
  subscription_status?: SubscriptionStatus;
  stripe_customer_id?: string | null;
  stripe_subscription_id?: string | null;
  subscription_period_end?: string | null;
  is_admin?: boolean;
  messages_today?: number;
  messages_reset_at?: string;
  preferences?: Record<string, unknown> | null;
  timezone?: string | null;
}

export interface ProfileUpdate {
  email?: string;
  full_name?: string | null;
  avatar_url?: string | null;
  date_of_birth?: string | null;
  age_tier?: AgeTier;
  is_minor_flagged?: boolean;
  minor_flagged_at?: string | null;
  minor_flag_reason?: string | null;
  behavioral_profile?: BehavioralProfile | null;
  subscription_tier?: SubscriptionTier;
  subscription_status?: SubscriptionStatus;
  stripe_customer_id?: string | null;
  stripe_subscription_id?: string | null;
  subscription_period_end?: string | null;
  is_admin?: boolean;
  messages_today?: number;
  messages_reset_at?: string;
  preferences?: Record<string, unknown> | null;
  timezone?: string | null;
  updated_at?: string;
}

// ============================================================================
// COMPANIONS TABLE
// ============================================================================

export interface Companion {
  id: string;
  user_id: string;
  name: string;
  avatar_url: string | null;
  avatar_3d_config: Avatar3DConfig | null;
  relationship_type: RelationshipType;
  relationship_label: string | null;
  personality_base: PersonalityBase | null;
  backstory: string | null;
  affection_level: number;
  trust_level: number;
  current_mood: MoodState | null;
  needs: CompanionNeeds | null;
  voice_config: VoiceConfig | null;
  interests: string[];
  quirks: string[];
  total_messages: number;
  total_voice_minutes: number;
  total_activities: number;
  last_interaction: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface CompanionInsert {
  user_id: string;
  name: string;
  avatar_url?: string | null;
  avatar_3d_config?: Avatar3DConfig | null;
  relationship_type: RelationshipType;
  relationship_label?: string | null;
  personality_base?: PersonalityBase | null;
  backstory?: string | null;
  affection_level?: number;
  trust_level?: number;
  current_mood?: MoodState | null;
  needs?: CompanionNeeds | null;
  voice_config?: VoiceConfig | null;
  interests?: string[];
  quirks?: string[];
  is_active?: boolean;
}

export interface CompanionUpdate {
  name?: string;
  avatar_url?: string | null;
  avatar_3d_config?: Avatar3DConfig | null;
  relationship_type?: RelationshipType;
  relationship_label?: string | null;
  personality_base?: PersonalityBase | null;
  backstory?: string | null;
  affection_level?: number;
  trust_level?: number;
  current_mood?: MoodState | null;
  needs?: CompanionNeeds | null;
  voice_config?: VoiceConfig | null;
  interests?: string[];
  quirks?: string[];
  total_messages?: number;
  total_voice_minutes?: number;
  total_activities?: number;
  last_interaction?: string | null;
  is_active?: boolean;
  updated_at?: string;
}

// ============================================================================
// COMPANION DNA TABLE
// ============================================================================

export interface CompanionDNA {
  id: string;
  companion_id: string;
  communication_dialect: CommunicationDialect | null;
  emotional_patterns: EmotionalPatterns | null;
  core_traits: CoreTraits | null;
  learning_style_matrix: Record<string, number> | null;
  humor_genome: Record<string, number> | null;
  emotional_resonance_map: Record<string, number> | null;
  interest_evolution_tree: Record<string, unknown> | null;
  memory_weighting_algorithm: Record<string, number> | null;
  growth_areas: string[];
  personality_version: number;
  last_evolution: string | null;
  created_at: string;
  updated_at: string;
}

export interface CompanionDNAInsert {
  companion_id: string;
  communication_dialect?: CommunicationDialect | null;
  emotional_patterns?: EmotionalPatterns | null;
  core_traits?: CoreTraits | null;
  learning_style_matrix?: Record<string, number> | null;
  humor_genome?: Record<string, number> | null;
  emotional_resonance_map?: Record<string, number> | null;
  interest_evolution_tree?: Record<string, unknown> | null;
  memory_weighting_algorithm?: Record<string, number> | null;
  growth_areas?: string[];
  personality_version?: number;
  last_evolution?: string | null;
}

// ============================================================================
// CONVERSATIONS TABLE
// ============================================================================

export interface Conversation {
  id: string;
  companion_id: string;
  user_id: string;
  title: string | null;
  summary: string | null;
  message_count: number;
  last_message_at: string | null;
  mood_summary: MoodState | null;
  topics: string[];
  is_archived: boolean;
  created_at: string;
  updated_at: string;
}

export interface ConversationInsert {
  companion_id: string;
  user_id: string;
  title?: string | null;
  summary?: string | null;
  mood_summary?: MoodState | null;
  topics?: string[];
  is_archived?: boolean;
}

export interface ConversationUpdate {
  title?: string | null;
  summary?: string | null;
  message_count?: number;
  last_message_at?: string | null;
  mood_summary?: MoodState | null;
  topics?: string[];
  is_archived?: boolean;
  updated_at?: string;
}

// ============================================================================
// MESSAGES TABLE
// ============================================================================

export interface Message {
  id: string;
  conversation_id: string;
  companion_id: string;
  user_id: string;
  role: MessageRole;
  content: string;
  content_type: ContentType;
  tokens_used: number;
  audio_url: string | null;
  audio_duration: number | null;
  metadata: Record<string, unknown> | null;
  is_edited: boolean;
  is_deleted: boolean;
  created_at: string;
  updated_at: string;
}

export interface MessageInsert {
  conversation_id: string;
  companion_id: string;
  user_id: string;
  role: MessageRole;
  content: string;
  content_type?: ContentType;
  tokens_used?: number;
  audio_url?: string | null;
  audio_duration?: number | null;
  metadata?: Record<string, unknown> | null;
}

// ============================================================================
// MEMORY CATEGORIES TABLE
// ============================================================================

export interface MemoryCategoryRow {
  id: string;
  name: string;
  description: string | null;
  icon: string | null;
  color: string | null;
  priority: number;
  is_system: boolean;
  created_at: string;
}

// ============================================================================
// MEMORIES TABLE
// ============================================================================

export interface Memory {
  id: string;
  companion_id: string;
  category_id: string | null;
  title: string | null;
  content: string;
  embedding: number[] | null;
  importance_score: number;
  emotional_context: MoodState | null;
  source_message_id: string | null;
  source_conversation_id: string | null;
  is_core_memory: boolean;
  last_accessed: string | null;
  access_count: number;
  created_at: string;
  updated_at: string;
}

export interface MemoryInsert {
  companion_id: string;
  category_id?: string | null;
  title?: string | null;
  content: string;
  embedding?: number[] | null;
  importance_score?: number;
  emotional_context?: MoodState | null;
  source_message_id?: string | null;
  source_conversation_id?: string | null;
  is_core_memory?: boolean;
}

export interface MemoryUpdate {
  category_id?: string | null;
  title?: string | null;
  content?: string;
  embedding?: number[] | null;
  importance_score?: number;
  emotional_context?: MoodState | null;
  is_core_memory?: boolean;
  last_accessed?: string | null;
  access_count?: number;
  updated_at?: string;
}

export interface MemoryWithCategory extends Memory {
  memory_categories: MemoryCategoryRow | null;
}

// ============================================================================
// LIFE EVENTS TABLE
// ============================================================================

export interface LifeEvent {
  id: string;
  companion_id: string;
  event_type: EventType;
  title: string;
  description: string | null;
  narrative: string | null;
  emoji: string | null;
  significance: 'trivial' | 'minor' | 'moderate' | 'major' | 'milestone';
  occurred_at: string;
  scheduled_at: string | null;
  completed_at: string | null;
  duration_minutes: number | null;
  mood_before: MoodState | null;
  mood_after: MoodState | null;
  involves_user: boolean;
  should_notify_user: boolean;
  notification_message: string | null;
  notified_at: string | null;
  shareable: boolean;
  shared_with_user: boolean;
  metadata: Record<string, unknown> | null;
  created_at: string;
}

export interface LifeEventInsert {
  companion_id: string;
  event_type: EventType;
  title: string;
  description?: string | null;
  narrative?: string | null;
  emoji?: string | null;
  significance?: 'trivial' | 'minor' | 'moderate' | 'major' | 'milestone';
  occurred_at?: string;
  scheduled_at?: string | null;
  duration_minutes?: number | null;
  mood_before?: MoodState | null;
  mood_after?: MoodState | null;
  involves_user?: boolean;
  should_notify_user?: boolean;
  notification_message?: string | null;
  shareable?: boolean;
  metadata?: Record<string, unknown> | null;
}

// ============================================================================
// ACTIVITIES TABLE
// ============================================================================

export interface Activity {
  id: string;
  name: string;
  description: string | null;
  category: string;
  duration_minutes: number;
  energy_cost: number;
  fun_value: number;
  social_value: number;
  creativity_value: number;
  intellectual_value: number;
  min_tier: SubscriptionTier;
  is_multiplayer: boolean;
  is_active: boolean;
  icon: string | null;
  created_at: string;
}

// ============================================================================
// ACTIVITY SESSIONS TABLE
// ============================================================================

export interface ActivitySession {
  id: string;
  activity_id: string;
  companion_id: string;
  user_id: string;
  started_at: string;
  ended_at: string | null;
  duration_minutes: number | null;
  score: number | null;
  outcome: Record<string, unknown> | null;
  created_at: string;
}

export interface ActivitySessionInsert {
  activity_id: string;
  companion_id: string;
  user_id: string;
  started_at?: string;
  ended_at?: string | null;
  duration_minutes?: number | null;
  score?: number | null;
  outcome?: Record<string, unknown> | null;
}

// ============================================================================
// CRISIS LOGS TABLE
// ============================================================================

export interface CrisisLog {
  id: string;
  user_id: string;
  companion_id: string | null;
  conversation_id: string | null;
  message_excerpt: string;
  crisis_type: CrisisType;
  severity: CrisisSeverity;
  keywords_matched: string[];
  response_provided: string;
  reviewed: boolean;
  reviewed_by: string | null;
  reviewed_at: string | null;
  notes: string | null;
  created_at: string;
}

export interface CrisisLogInsert {
  user_id: string;
  companion_id?: string | null;
  conversation_id?: string | null;
  message_excerpt: string;
  crisis_type: CrisisType;
  severity: CrisisSeverity;
  keywords_matched: string[];
  response_provided: string;
  reviewed?: boolean;
  reviewed_by?: string | null;
  reviewed_at?: string | null;
  notes?: string | null;
}

// ============================================================================
// BEHAVIORAL DETECTION LOGS TABLE
// ============================================================================

export interface BehavioralDetectionLog {
  id: string;
  user_id: string;
  message_excerpt: string;
  triggers: string[];
  categories: string[];
  confidence: number;
  detected_age: number | null;
  resulted_in_flag: boolean;
  reviewed: boolean;
  reviewed_by: string | null;
  reviewed_at: string | null;
  created_at: string;
}

export interface BehavioralDetectionLogInsert {
  user_id: string;
  message_excerpt: string;
  triggers: string[];
  categories: string[];
  confidence: number;
  detected_age?: number | null;
  resulted_in_flag?: boolean;
  reviewed?: boolean;
}

// ============================================================================
// DATA EXPORTS TABLE
// ============================================================================

export interface DataExport {
  id: string;
  user_id: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  file_url: string | null;
  file_size: number | null;
  expires_at: string | null;
  error_message: string | null;
  requested_at: string;
  completed_at: string | null;
}

export interface DataExportInsert {
  user_id: string;
  status?: 'pending' | 'processing' | 'completed' | 'failed';
}

// ============================================================================
// AUDIT LOGS TABLE
// ============================================================================

export interface AuditLog {
  id: string;
  user_id: string;
  action: string;
  resource_type: string;
  resource_id: string | null;
  details: Record<string, unknown> | null;
  ip_address: string | null;
  user_agent: string | null;
  created_at: string;
}

export interface AuditLogInsert {
  user_id: string;
  action: string;
  resource_type: string;
  resource_id?: string | null;
  details?: Record<string, unknown> | null;
  ip_address?: string | null;
  user_agent?: string | null;
}

// ============================================================================
// MEMORY ACCESS LOG TABLE
// ============================================================================

export interface MemoryAccessLog {
  id: string;
  memory_id: string;
  companion_id: string;
  access_type: 'retrieval' | 'update' | 'reinforcement';
  context: string | null;
  created_at: string;
}

export interface MemoryAccessLogInsert {
  memory_id: string;
  companion_id: string;
  access_type: 'retrieval' | 'update' | 'reinforcement';
  context?: string | null;
}

// ============================================================================
// RELATIONSHIP MILESTONES TABLE
// ============================================================================

export interface RelationshipMilestone {
  id: string;
  companion_id: string;
  user_id: string;
  milestone_type: string;
  title: string;
  description: string | null;
  threshold_value: number | null;
  achieved_value: number | null;
  unlocks: string[];
  achieved_at: string;
  celebrated: boolean;
  created_at: string;
}

export interface RelationshipMilestoneInsert {
  companion_id: string;
  user_id: string;
  milestone_type: string;
  title: string;
  description?: string | null;
  threshold_value?: number | null;
  achieved_value?: number | null;
  unlocks?: string[];
  achieved_at?: string;
  celebrated?: boolean;
}

// ============================================================================
// USER ACHIEVEMENTS TABLE
// ============================================================================

export interface UserAchievement {
  id: string;
  user_id: string;
  achievement_id: string;
  title: string;
  description: string | null;
  icon: string | null;
  rarity: 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';
  xp_reward: number;
  unlocked_at: string;
  created_at: string;
}

export interface UserAchievementInsert {
  user_id: string;
  achievement_id: string;
  title: string;
  description?: string | null;
  icon?: string | null;
  rarity?: 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';
  xp_reward?: number;
  unlocked_at?: string;
}

// ============================================================================
// PROACTIVE MESSAGES TABLE
// ============================================================================

export interface ProactiveMessage {
  id: string;
  companion_id: string;
  user_id: string;
  trigger_type: string;
  content: string;
  metadata: Record<string, unknown> | null;
  read: boolean;
  read_at: string | null;
  created_at: string;
}

export interface ProactiveMessageInsert {
  companion_id: string;
  user_id: string;
  trigger_type: string;
  content: string;
  metadata?: Record<string, unknown> | null;
}

// ============================================================================
// COMPANION WITH DNA (Join Type)
// ============================================================================

export interface CompanionWithDNA extends Companion {
  companion_dna: CompanionDNA[] | null;
}

// ============================================================================
// SUPABASE DATABASE TYPE
// ============================================================================

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: Profile;
        Insert: ProfileInsert;
        Update: ProfileUpdate;
      };
      companions: {
        Row: Companion;
        Insert: CompanionInsert;
        Update: CompanionUpdate;
      };
      companion_dna: {
        Row: CompanionDNA;
        Insert: CompanionDNAInsert;
        Update: Partial<CompanionDNA>;
      };
      conversations: {
        Row: Conversation;
        Insert: ConversationInsert;
        Update: ConversationUpdate;
      };
      messages: {
        Row: Message;
        Insert: MessageInsert;
        Update: Partial<Message>;
      };
      memory_categories: {
        Row: MemoryCategoryRow;
        Insert: Omit<MemoryCategoryRow, 'id' | 'created_at'>;
        Update: Partial<MemoryCategoryRow>;
      };
      memories: {
        Row: Memory;
        Insert: MemoryInsert;
        Update: MemoryUpdate;
      };
      life_events: {
        Row: LifeEvent;
        Insert: LifeEventInsert;
        Update: Partial<LifeEvent>;
      };
      activities: {
        Row: Activity;
        Insert: Omit<Activity, 'id' | 'created_at'>;
        Update: Partial<Activity>;
      };
      activity_sessions: {
        Row: ActivitySession;
        Insert: ActivitySessionInsert;
        Update: Partial<ActivitySession>;
      };
      crisis_logs: {
        Row: CrisisLog;
        Insert: CrisisLogInsert;
        Update: Partial<CrisisLog>;
      };
      behavioral_detection_logs: {
        Row: BehavioralDetectionLog;
        Insert: BehavioralDetectionLogInsert;
        Update: Partial<BehavioralDetectionLog>;
      };
      data_exports: {
        Row: DataExport;
        Insert: DataExportInsert;
        Update: Partial<DataExport>;
      };
      audit_logs: {
        Row: AuditLog;
        Insert: AuditLogInsert;
        Update: Partial<AuditLog>;
      };
      memory_access_log: {
        Row: MemoryAccessLog;
        Insert: MemoryAccessLogInsert;
        Update: Partial<MemoryAccessLog>;
      };
      relationship_milestones: {
        Row: RelationshipMilestone;
        Insert: RelationshipMilestoneInsert;
        Update: Partial<RelationshipMilestone>;
      };
      user_achievements: {
        Row: UserAchievement;
        Insert: UserAchievementInsert;
        Update: Partial<UserAchievement>;
      };
      proactive_messages: {
        Row: ProactiveMessage;
        Insert: ProactiveMessageInsert;
        Update: Partial<ProactiveMessage>;
      };
    };
    Views: Record<string, never>;
    Functions: {
      match_memories: {
        Args: {
          query_embedding: number[];
          match_threshold: number;
          match_count: number;
          p_companion_id: string;
        };
        Returns: Array<{
          id: string;
          content: string;
          similarity: number;
        }>;
      };
    };
    Enums: {
      subscription_tier: SubscriptionTier;
      subscription_status: SubscriptionStatus;
      age_tier: AgeTier;
      relationship_type: RelationshipType;
      message_role: MessageRole;
      content_type: ContentType;
      crisis_type: CrisisType;
      crisis_severity: CrisisSeverity;
      event_type: EventType;
    };
  };
}
