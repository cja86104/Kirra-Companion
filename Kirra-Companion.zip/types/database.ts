// =============================================================================
// DATABASE TYPES - KIRRA COMPANION
// =============================================================================

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          email: string;
          full_name: string | null;
          avatar_url: string | null;
          date_of_birth: string | null;
          age_tier: 'blocked' | 'minor' | 'adult';
          is_minor_flagged: boolean;
          minor_flagged_at: string | null;
          minor_flag_reason: string | null;
          behavioral_profile: Json | null;
          subscription_tier: 'free' | 'basic' | 'pro' | 'ultimate';
          subscription_status: 'active' | 'canceled' | 'past_due' | 'trialing' | 'incomplete';
          stripe_customer_id: string | null;
          stripe_subscription_id: string | null;
          subscription_period_end: string | null;
          is_admin: boolean;
          messages_today: number;
          messages_reset_at: string;
          preferences: Json;
          timezone: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          email: string;
          full_name?: string | null;
          avatar_url?: string | null;
          date_of_birth?: string | null;
          age_tier?: 'blocked' | 'minor' | 'adult';
          is_minor_flagged?: boolean;
          minor_flagged_at?: string | null;
          minor_flag_reason?: string | null;
          behavioral_profile?: Json | null;
          subscription_tier?: 'free' | 'basic' | 'pro' | 'ultimate';
          subscription_status?: 'active' | 'canceled' | 'past_due' | 'trialing' | 'incomplete';
          stripe_customer_id?: string | null;
          stripe_subscription_id?: string | null;
          subscription_period_end?: string | null;
          is_admin?: boolean;
          messages_today?: number;
          messages_reset_at?: string;
          preferences?: Json;
          timezone?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          email?: string;
          full_name?: string | null;
          avatar_url?: string | null;
          date_of_birth?: string | null;
          age_tier?: 'blocked' | 'minor' | 'adult';
          is_minor_flagged?: boolean;
          minor_flagged_at?: string | null;
          minor_flag_reason?: string | null;
          behavioral_profile?: Json | null;
          subscription_tier?: 'free' | 'basic' | 'pro' | 'ultimate';
          subscription_status?: 'active' | 'canceled' | 'past_due' | 'trialing' | 'incomplete';
          stripe_customer_id?: string | null;
          stripe_subscription_id?: string | null;
          subscription_period_end?: string | null;
          is_admin?: boolean;
          messages_today?: number;
          messages_reset_at?: string;
          preferences?: Json;
          timezone?: string;
          created_at?: string;
          updated_at?: string;
        };
      };
      companions: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          avatar_url: string | null;
          avatar_3d_config: Json | null;
          relationship_type: 'friend' | 'mentor' | 'romantic' | 'family' | 'custom';
          relationship_label: string | null;
          personality_base: Json;
          backstory: string | null;
          affection_level: number;
          trust_level: number;
          current_mood: Json;
          needs: Json;
          voice_config: Json | null;
          interests: string[];
          quirks: string[];
          total_messages: number;
          total_voice_minutes: number;
          total_activities: number;
          last_interaction: string | null;
          is_active: boolean;
          is_archived: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          name: string;
          avatar_url?: string | null;
          avatar_3d_config?: Json | null;
          relationship_type?: 'friend' | 'mentor' | 'romantic' | 'family' | 'custom';
          relationship_label?: string | null;
          personality_base?: Json;
          backstory?: string | null;
          affection_level?: number;
          trust_level?: number;
          current_mood?: Json;
          needs?: Json;
          voice_config?: Json | null;
          interests?: string[];
          quirks?: string[];
          total_messages?: number;
          total_voice_minutes?: number;
          total_activities?: number;
          last_interaction?: string | null;
          is_active?: boolean;
          is_archived?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          name?: string;
          avatar_url?: string | null;
          avatar_3d_config?: Json | null;
          relationship_type?: 'friend' | 'mentor' | 'romantic' | 'family' | 'custom';
          relationship_label?: string | null;
          personality_base?: Json;
          backstory?: string | null;
          affection_level?: number;
          trust_level?: number;
          current_mood?: Json;
          needs?: Json;
          voice_config?: Json | null;
          interests?: string[];
          quirks?: string[];
          total_messages?: number;
          total_voice_minutes?: number;
          total_activities?: number;
          last_interaction?: string | null;
          is_active?: boolean;
          is_archived?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      companion_dna: {
        Row: {
          id: string;
          companion_id: string;
          communication_dialect: Json;
          emotional_patterns: Json;
          core_traits: Json;
          learning_style_matrix: Json;
          humor_genome: Json;
          emotional_resonance_map: Json;
          interest_evolution_tree: Json;
          memory_weighting_algorithm: Json;
          growth_areas: string[];
          personality_version: number;
          last_evolution: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          companion_id: string;
          communication_dialect?: Json;
          emotional_patterns?: Json;
          core_traits?: Json;
          learning_style_matrix?: Json;
          humor_genome?: Json;
          emotional_resonance_map?: Json;
          interest_evolution_tree?: Json;
          memory_weighting_algorithm?: Json;
          growth_areas?: string[];
          personality_version?: number;
          last_evolution?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          companion_id?: string;
          communication_dialect?: Json;
          emotional_patterns?: Json;
          core_traits?: Json;
          learning_style_matrix?: Json;
          humor_genome?: Json;
          emotional_resonance_map?: Json;
          interest_evolution_tree?: Json;
          memory_weighting_algorithm?: Json;
          growth_areas?: string[];
          personality_version?: number;
          last_evolution?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      conversations: {
        Row: {
          id: string;
          companion_id: string;
          user_id: string;
          title: string | null;
          summary: string | null;
          message_count: number;
          last_message_at: string | null;
          mood_summary: Json | null;
          topics: string[];
          is_archived: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          companion_id: string;
          user_id: string;
          title?: string | null;
          summary?: string | null;
          message_count?: number;
          last_message_at?: string | null;
          mood_summary?: Json | null;
          topics?: string[];
          is_archived?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          companion_id?: string;
          user_id?: string;
          title?: string | null;
          summary?: string | null;
          message_count?: number;
          last_message_at?: string | null;
          mood_summary?: Json | null;
          topics?: string[];
          is_archived?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      messages: {
        Row: {
          id: string;
          conversation_id: string;
          companion_id: string;
          user_id: string;
          role: 'user' | 'companion' | 'system';
          content: string;
          content_type: 'text' | 'image' | 'audio' | 'file';
          tokens_used: number;
          audio_url: string | null;
          audio_duration: number | null;
          metadata: Json | null;
          is_edited: boolean;
          is_deleted: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          conversation_id: string;
          companion_id: string;
          user_id: string;
          role: 'user' | 'companion' | 'system';
          content: string;
          content_type?: 'text' | 'image' | 'audio' | 'file';
          tokens_used?: number;
          audio_url?: string | null;
          audio_duration?: number | null;
          metadata?: Json | null;
          is_edited?: boolean;
          is_deleted?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          conversation_id?: string;
          companion_id?: string;
          user_id?: string;
          role?: 'user' | 'companion' | 'system';
          content?: string;
          content_type?: 'text' | 'image' | 'audio' | 'file';
          tokens_used?: number;
          audio_url?: string | null;
          audio_duration?: number | null;
          metadata?: Json | null;
          is_edited?: boolean;
          is_deleted?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      memories: {
        Row: {
          id: string;
          companion_id: string;
          user_id: string;
          conversation_id: string | null;
          message_id: string | null;
          content: string;
          summary: string | null;
          memory_type: string;
          importance: number;
          emotional_weight: number;
          embedding: number[] | null;
          tags: string[];
          context: Json | null;
          access_count: number;
          last_accessed: string | null;
          is_core_memory: boolean;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          companion_id: string;
          user_id: string;
          conversation_id?: string | null;
          message_id?: string | null;
          content: string;
          summary?: string | null;
          memory_type?: string;
          importance?: number;
          emotional_weight?: number;
          embedding?: number[] | null;
          tags?: string[];
          context?: Json | null;
          access_count?: number;
          last_accessed?: string | null;
          is_core_memory?: boolean;
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          companion_id?: string;
          user_id?: string;
          conversation_id?: string | null;
          message_id?: string | null;
          content?: string;
          summary?: string | null;
          memory_type?: string;
          importance?: number;
          emotional_weight?: number;
          embedding?: number[] | null;
          tags?: string[];
          context?: Json | null;
          access_count?: number;
          last_accessed?: string | null;
          is_core_memory?: boolean;
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      life_events: {
        Row: {
          id: string;
          companion_id: string;
          event_type: string;
          title: string;
          description: string;
          significance: 'trivial' | 'minor' | 'moderate' | 'major' | 'milestone';
          emotional_impact: Json | null;
          triggered_by: string | null;
          metadata: Json | null;
          is_shared: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          companion_id: string;
          event_type: string;
          title: string;
          description: string;
          significance?: 'trivial' | 'minor' | 'moderate' | 'major' | 'milestone';
          emotional_impact?: Json | null;
          triggered_by?: string | null;
          metadata?: Json | null;
          is_shared?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          companion_id?: string;
          event_type?: string;
          title?: string;
          description?: string;
          significance?: 'trivial' | 'minor' | 'moderate' | 'major' | 'milestone';
          emotional_impact?: Json | null;
          triggered_by?: string | null;
          metadata?: Json | null;
          is_shared?: boolean;
          created_at?: string;
        };
      };
      companion_skills: {
        Row: {
          id: string;
          companion_id: string;
          skill_name: string;
          skill_category: string;
          proficiency_level: number;
          times_used: number;
          last_used: string | null;
          learned_from: string | null;
          metadata: Json | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          companion_id: string;
          skill_name: string;
          skill_category?: string;
          proficiency_level?: number;
          times_used?: number;
          last_used?: string | null;
          learned_from?: string | null;
          metadata?: Json | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          companion_id?: string;
          skill_name?: string;
          skill_category?: string;
          proficiency_level?: number;
          times_used?: number;
          last_used?: string | null;
          learned_from?: string | null;
          metadata?: Json | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      proactive_messages: {
        Row: {
          id: string;
          companion_id: string;
          user_id: string;
          trigger_type: string;
          message_content: string;
          priority: number;
          status: string;
          scheduled_for: string | null;
          sent_at: string | null;
          read_at: string | null;
          metadata: Json | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          companion_id: string;
          user_id: string;
          trigger_type: string;
          message_content: string;
          priority?: number;
          status?: string;
          scheduled_for?: string | null;
          sent_at?: string | null;
          read_at?: string | null;
          metadata?: Json | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          companion_id?: string;
          user_id?: string;
          trigger_type?: string;
          message_content?: string;
          priority?: number;
          status?: string;
          scheduled_for?: string | null;
          sent_at?: string | null;
          read_at?: string | null;
          metadata?: Json | null;
          created_at?: string;
        };
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      [_ in never]: never;
    };
    Enums: {
      subscription_tier: 'free' | 'basic' | 'pro' | 'ultimate';
      subscription_status: 'active' | 'canceled' | 'past_due' | 'trialing' | 'incomplete';
      age_tier: 'blocked' | 'minor' | 'adult';
      relationship_type: 'friend' | 'mentor' | 'romantic' | 'family' | 'custom';
      message_role: 'user' | 'companion' | 'system';
      content_type: 'text' | 'image' | 'audio' | 'file';
      event_significance: 'trivial' | 'minor' | 'moderate' | 'major' | 'milestone';
    };
    CompositeTypes: {
      [_ in never]: never;
    };
  };
}

// =============================================================================
// HELPER TYPES
// =============================================================================

export type Tables<T extends keyof Database['public']['Tables']> =
  Database['public']['Tables'][T]['Row'];

export type InsertTables<T extends keyof Database['public']['Tables']> =
  Database['public']['Tables'][T]['Insert'];

export type UpdateTables<T extends keyof Database['public']['Tables']> =
  Database['public']['Tables'][T]['Update'];

// =============================================================================
// CONVENIENCE EXPORTS - ROW TYPES
// =============================================================================

export type Profile = Tables<'profiles'>;
export type Companion = Tables<'companions'>;
export type CompanionDNA = Tables<'companion_dna'>;
export type Conversation = Tables<'conversations'>;
export type Message = Tables<'messages'>;
export type Memory = Tables<'memories'>;
export type LifeEvent = Tables<'life_events'>;
export type CompanionSkill = Tables<'companion_skills'>;
export type ProactiveMessage = Tables<'proactive_messages'>;

// =============================================================================
// INSERT TYPES
// =============================================================================

export type ProfileInsert = InsertTables<'profiles'>;
export type CompanionInsert = InsertTables<'companions'>;
export type CompanionDNAInsert = InsertTables<'companion_dna'>;
export type ConversationInsert = InsertTables<'conversations'>;
export type MessageInsert = InsertTables<'messages'>;
export type MemoryInsert = InsertTables<'memories'>;
export type CompanionSkillInsert = InsertTables<'companion_skills'>;
export type ProactiveMessageInsert = InsertTables<'proactive_messages'>;

// =============================================================================
// UPDATE TYPES
// =============================================================================

export type ProfileUpdate = UpdateTables<'profiles'>;
export type CompanionUpdate = UpdateTables<'companions'>;
export type CompanionDNAUpdate = UpdateTables<'companion_dna'>;
export type ConversationUpdate = UpdateTables<'conversations'>;
export type MessageUpdate = UpdateTables<'messages'>;
export type MemoryUpdate = UpdateTables<'memories'>;
export type CompanionSkillUpdate = UpdateTables<'companion_skills'>;
export type ProactiveMessageUpdate = UpdateTables<'proactive_messages'>;

// =============================================================================
// PLACEHOLDER TYPES FOR OPTIONAL TABLES
// These tables may or may not exist in your Supabase schema.
// If they don't exist, these types allow the code to compile.
// =============================================================================

export interface MemoryCategoryRow {
  id: string;
  name: string;
  icon: string | null;
  color: string | null;
  description: string | null;
  created_at: string;
}

export interface Activity {
  id: string;
  name: string;
  description: string | null;
  activity_type: string;
  min_tier: string;
  is_active: boolean;
  config: Json | null;
  created_at: string;
}

export interface ActivitySession {
  id: string;
  activity_id: string;
  companion_id: string;
  user_id: string;
  started_at: string;
  ended_at: string | null;
  score: number | null;
  metadata: Json | null;
}
export type ActivitySessionInsert = Partial<ActivitySession> & { activity_id: string; companion_id: string; user_id: string };

export interface CrisisLog {
  id: string;
  user_id: string;
  companion_id: string | null;
  severity: string;
  detected_content: string;
  action_taken: string;
  created_at: string;
}
export type CrisisLogInsert = Partial<CrisisLog> & { user_id: string; severity: string; detected_content: string; action_taken: string };

export interface BehavioralDetectionLog {
  id: string;
  user_id: string;
  detection_type: string;
  confidence: number;
  metadata: Json | null;
  created_at: string;
}
export type BehavioralDetectionLogInsert = Partial<BehavioralDetectionLog> & { user_id: string; detection_type: string; confidence: number };

export interface DataExport {
  id: string;
  user_id: string;
  status: string;
  file_url: string | null;
  requested_at: string;
  completed_at: string | null;
  expires_at: string | null;
}
export type DataExportInsert = Partial<DataExport> & { user_id: string };

export interface AuditLog {
  id: string;
  user_id: string;
  action: string;
  resource_type: string;
  resource_id: string | null;
  metadata: Json | null;
  ip_address: string | null;
  created_at: string;
}
export type AuditLogInsert = Partial<AuditLog> & { user_id: string; action: string; resource_type: string };

export interface MemoryAccessLog {
  id: string;
  memory_id: string;
  accessed_by: string;
  access_type: string;
  created_at: string;
}
export type MemoryAccessLogInsert = Partial<MemoryAccessLog> & { memory_id: string; accessed_by: string; access_type: string };

export interface RelationshipMilestone {
  id: string;
  companion_id: string;
  milestone_type: string;
  title: string;
  description: string | null;
  achieved_at: string;
  metadata: Json | null;
}
export type RelationshipMilestoneInsert = Partial<RelationshipMilestone> & { companion_id: string; milestone_type: string; title: string };

export interface UserAchievement {
  id: string;
  user_id: string;
  achievement_type: string;
  title: string;
  description: string | null;
  unlocked_at: string;
  metadata: Json | null;
}
export type UserAchievementInsert = Partial<UserAchievement> & { user_id: string; achievement_type: string; title: string };

// Communication dialect structure
export interface CommunicationDialect {
  uniquePhrases?: string[];
  favoriteExpressions?: string[];
  speechPatterns?: string[];
  vocabularyLevel?: string;
  formalityPreference?: number;
}

// =============================================================================
// ADDITIONAL TYPES USED ACROSS THE APP
// =============================================================================

// Emotion types
export type EmotionType =
  | 'happy'
  | 'sad'
  | 'excited'
  | 'calm'
  | 'curious'
  | 'loving'
  | 'playful'
  | 'thoughtful'
  | 'neutral'
  | 'anxious'
  | 'proud'
  | 'grateful';

// Mood state interface
export interface MoodState {
  primary: EmotionType;
  secondary?: EmotionType | null;
  intensity: number;
  lastUpdated?: string | null;
}

// Voice configuration - supports both OpenAI and ElevenLabs
export interface VoiceConfig {
  provider: 'elevenlabs' | 'openai';
  voiceId: string | null;
  // OpenAI TTS options
  model?: string;
  speed?: number;
  // ElevenLabs options (deprecated but kept for backwards compatibility)
  stability?: number;
  similarityBoost?: number;
  style?: number;
  speakingRate?: number;
}

// Companion with DNA joined
export interface CompanionWithDNA extends Companion {
  companion_dna: CompanionDNA | null;
}

// Life event insert type
export type LifeEventInsert = InsertTables<'life_events'>;

// Event type for life events
export type EventType = 
  | 'discovery'
  | 'achievement'
  | 'relationship'
  | 'mood_shift'
  | 'growth'
  | 'memory'
  | 'skill_learned'
  | 'interest_developed'
  | 'milestone'
  | 'daily_reflection';

// Memory with category
export interface MemoryWithCategory extends Memory {
  category?: string;
}
