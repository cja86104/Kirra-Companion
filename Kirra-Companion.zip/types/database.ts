/**
 * Kirra Companion - Database Types
 * Auto-generated Supabase types with manual extensions
 * 
 * This file defines the complete database schema types for TypeScript
 * Usage: import type { Database, Profile, Companion } from '@/types/database';
 */

// ============================================================
// JSON Types (for JSONB columns)
// ============================================================

export interface PersonalityBase {
  openness: number;
  conscientiousness: number;
  extraversion: number;
  agreeableness: number;
  neuroticism: number;
  humor: number;
  empathy: number;
  curiosity: number;
  playfulness: number;
  assertiveness: number;
}

export interface MoodState {
  primary: string;
  secondary?: string | null;
  intensity: number;
  lastUpdated?: string | null;
}

export interface Avatar3DConfig {
  model: string;
  skinTone: string;
  hairColor: string;
  hairStyle: string;
  eyeColor: string;
  expression: string;
  outfit: string;
  accessories: string[];
}

export interface VoiceConfig {
  provider: 'elevenlabs' | 'openai';
  voiceId: string;
  // OpenAI specific
  model?: 'tts-1' | 'tts-1-hd';
  speed?: number; // 0.25 to 4.0
  // ElevenLabs specific (legacy)
  stability?: number;
  similarityBoost?: number;
  style?: number;
  speakingRate?: number;
}

export interface CompanionNeeds {
  social: number;
  energy: number;
  fun: number;
  comfort: number;
  affection: number;
  intellectual: number;
  creativity: number;
  lastInteraction: string;
  lastDecay: string;
}

export interface CommunicationDialect {
  favoriteExpressions: string[];
  vocabularyLevel: 'simple' | 'moderate' | 'advanced' | 'adaptive';
  sentenceComplexity: number;
  emojiUsage: number;
  formalityLevel: number;
  uniquePhrases: string[];
  avoidedWords: string[];
  speechPatterns: string[];
}

export interface EmotionalPatterns {
  triggers: Record<string, string[]>;
  recoveryTime: number;
  expressionStyle: string;
  vulnerabilityLevel: number;
}

export interface CoreTraits {
  values: string[];
  fears: string[];
  dreams: string[];
  secretDesires: string[];
}

export interface GrowthAreas {
  currentFocus: string[];
  pastGrowth: string[];
  futureGoals: string[];
}

export interface LearningStyleMatrix {
  visualLearner: number;
  analyticalThinker: number;
  emotionalProcessor: number;
  practicalApproach: number;
  abstractReasoning: number;
  detailOriented: number;
  bigPictureFocus: number;
  sequentialLearning: number;
}

export interface HumorGenome {
  sarcasm: number;
  wordplay: number;
  observational: number;
  selfDeprecating: number;
  darkHumor: number;
  slapstick: number;
  intellectual: number;
  absurdist: number;
  timing: number;
  callbacks: number;
}

export interface EmotionalResonanceMap {
  joyResponse: number;
  sadnessSupport: number;
  angerHandling: number;
  fearComfort: number;
  surpriseReaction: number;
  disgustTolerance: number;
  empathyDepth: number;
  emotionalMirroring: number;
  boundaryAwareness: number;
  conflictResolution: number;
}

export interface InterestNode {
  id: string;
  name: string;
  level: number;
  source: string;
  developedAt: string;
}

export interface InterestConnection {
  from: string;
  to: string;
  strength: number;
}

export interface InterestEvolutionTree {
  roots: InterestNode[];
  branches: InterestNode[];
  leaves: InterestNode[];
  connections: InterestConnection[];
}

export interface MemoryWeightingAlgorithm {
  emotionalMoments: number;
  sharedExperiences: number;
  userPreferences: number;
  insideJokes: number;
  importantDates: number;
  userGoals: number;
  relationshipMilestones: number;
  conflictResolutions: number;
  dailyDetails: number;
  randomFacts: number;
}

export interface BehavioralProfile {
  flaggedPatterns: string[];
  lastAnalyzed: string | null;
  riskScore: number;
}

// ============================================================
// Enums
// ============================================================

export type SubscriptionTier = 'free' | 'basic' | 'pro' | 'ultimate';
export type SubscriptionStatus = 'active' | 'canceled' | 'past_due' | 'trialing' | 'unpaid';
export type AgeTier = 'blocked' | 'minor' | 'adult';
export type RelationshipType = 'friend' | 'mentor' | 'romantic' | 'family' | 'custom';
export type MessageRole = 'user' | 'companion' | 'system';
export type ContentType = 'text' | 'image' | 'voice' | 'file';
export type MemoryCategory = 'fact' | 'emotion' | 'preference' | 'event' | 'relationship' | 'goal';
export type EventType = 'activity' | 'mood_change' | 'milestone' | 'thought' | 'dream' | 'social';
export type CrisisType = 'self_harm' | 'suicide' | 'harm_others' | 'abuse' | 'emergency';
export type CrisisSeverity = 'low' | 'medium' | 'high' | 'critical';
export type ActivityType = 'game' | 'watch' | 'create' | 'learn' | 'exercise' | 'relax';

// ============================================================
// Database Schema Types
// ============================================================

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: Profile;
        Insert: ProfileInsert;
        Update: ProfileUpdate;
        Relationships: [];
      };
      companions: {
        Row: Companion;
        Insert: CompanionInsert;
        Update: CompanionUpdate;
        Relationships: [
          {
            foreignKeyName: "companions_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          }
        ];
      };
      companion_dna: {
        Row: CompanionDNA;
        Insert: CompanionDNAInsert;
        Update: CompanionDNAUpdate;
        Relationships: [
          {
            foreignKeyName: "companion_dna_companion_id_fkey";
            columns: ["companion_id"];
            isOneToOne: true;
            referencedRelation: "companions";
            referencedColumns: ["id"];
          }
        ];
      };
      conversations: {
        Row: Conversation;
        Insert: ConversationInsert;
        Update: ConversationUpdate;
        Relationships: [
          {
            foreignKeyName: "conversations_companion_id_fkey";
            columns: ["companion_id"];
            isOneToOne: false;
            referencedRelation: "companions";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "conversations_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          }
        ];
      };
      messages: {
        Row: Message;
        Insert: MessageInsert;
        Update: MessageUpdate;
        Relationships: [
          {
            foreignKeyName: "messages_conversation_id_fkey";
            columns: ["conversation_id"];
            isOneToOne: false;
            referencedRelation: "conversations";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "messages_companion_id_fkey";
            columns: ["companion_id"];
            isOneToOne: false;
            referencedRelation: "companions";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "messages_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          }
        ];
      };
      memories: {
        Row: Memory;
        Insert: MemoryInsert;
        Update: MemoryUpdate;
        Relationships: [
          {
            foreignKeyName: "memories_companion_id_fkey";
            columns: ["companion_id"];
            isOneToOne: false;
            referencedRelation: "companions";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "memories_category_id_fkey";
            columns: ["category_id"];
            isOneToOne: false;
            referencedRelation: "memory_categories";
            referencedColumns: ["id"];
          }
        ];
      };
      memory_categories: {
        Row: MemoryCategoryRow;
        Insert: MemoryCategoryInsert;
        Update: MemoryCategoryUpdate;
        Relationships: [];
      };
      life_events: {
        Row: LifeEvent;
        Insert: LifeEventInsert;
        Update: LifeEventUpdate;
        Relationships: [
          {
            foreignKeyName: "life_events_companion_id_fkey";
            columns: ["companion_id"];
            isOneToOne: false;
            referencedRelation: "companions";
            referencedColumns: ["id"];
          }
        ];
      };
      activities: {
        Row: Activity;
        Insert: ActivityInsert;
        Update: ActivityUpdate;
        Relationships: [];
      };
      activity_sessions: {
        Row: ActivitySession;
        Insert: ActivitySessionInsert;
        Update: ActivitySessionUpdate;
        Relationships: [
          {
            foreignKeyName: "activity_sessions_activity_id_fkey";
            columns: ["activity_id"];
            isOneToOne: false;
            referencedRelation: "activities";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "activity_sessions_companion_id_fkey";
            columns: ["companion_id"];
            isOneToOne: false;
            referencedRelation: "companions";
            referencedColumns: ["id"];
          }
        ];
      };
      crisis_logs: {
        Row: CrisisLog;
        Insert: CrisisLogInsert;
        Update: CrisisLogUpdate;
        Relationships: [
          {
            foreignKeyName: "crisis_logs_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          }
        ];
      };
      behavioral_detection_logs: {
        Row: BehavioralDetectionLog;
        Insert: BehavioralDetectionLogInsert;
        Update: BehavioralDetectionLogUpdate;
        Relationships: [
          {
            foreignKeyName: "behavioral_detection_logs_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          }
        ];
      };
      relationship_milestones: {
        Row: RelationshipMilestone;
        Insert: RelationshipMilestoneInsert;
        Update: RelationshipMilestoneUpdate;
        Relationships: [
          {
            foreignKeyName: "relationship_milestones_companion_id_fkey";
            columns: ["companion_id"];
            isOneToOne: false;
            referencedRelation: "companions";
            referencedColumns: ["id"];
          }
        ];
      };
      user_achievements: {
        Row: UserAchievement;
        Insert: UserAchievementInsert;
        Update: UserAchievementUpdate;
        Relationships: [
          {
            foreignKeyName: "user_achievements_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          }
        ];
      };
      data_exports: {
        Row: DataExport;
        Insert: DataExportInsert;
        Update: DataExportUpdate;
        Relationships: [
          {
            foreignKeyName: "data_exports_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          }
        ];
      };
      audit_logs: {
        Row: AuditLog;
        Insert: AuditLogInsert;
        Update: AuditLogUpdate;
        Relationships: [
          {
            foreignKeyName: "audit_logs_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          }
        ];
      };
      memory_access_log: {
        Row: MemoryAccessLog;
        Insert: MemoryAccessLogInsert;
        Update: MemoryAccessLogUpdate;
        Relationships: [
          {
            foreignKeyName: "memory_access_log_memory_id_fkey";
            columns: ["memory_id"];
            isOneToOne: false;
            referencedRelation: "memories";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "memory_access_log_companion_id_fkey";
            columns: ["companion_id"];
            isOneToOne: false;
            referencedRelation: "companions";
            referencedColumns: ["id"];
          }
        ];
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      match_memories: {
        Args: {
          query_embedding: number[];
          match_threshold: number;
          match_count: number;
          p_companion_id: string;
        };
        Returns: {
          id: string;
          content: string;
          similarity: number;
        }[];
      };
    };
    Enums: {
      subscription_tier: SubscriptionTier;
      subscription_status: SubscriptionStatus;
      age_tier: AgeTier;
      relationship_type: RelationshipType;
      message_role: MessageRole;
      content_type: ContentType;
      memory_category: MemoryCategory;
      event_type: EventType;
      crisis_type: CrisisType;
      crisis_severity: CrisisSeverity;
      activity_type: ActivityType;
    };
    CompositeTypes: {
      [_ in never]: never;
    };
  };
}

// ============================================================
// Table Row Types
// ============================================================

export interface Profile {
  id: string;
  email: string;
  full_name: string | null;
  avatar_url: string | null;
  date_of_birth: string | null;
  age_tier: AgeTier;
  is_minor_flagged: boolean;
  minor_flagged_at: string | null;
  minor_flag_reason: string | null;
  behavioral_profile: BehavioralProfile | null;
  subscription_tier: SubscriptionTier;
  subscription_status: SubscriptionStatus;
  stripe_customer_id: string | null;
  stripe_subscription_id: string | null;
  subscription_period_end: string | null;
  is_admin: boolean;
  messages_today: number;
  messages_reset_at: string;
  voice_characters_used: number;
  voice_characters_reset_at: string | null;
  streak_days: number;
  last_active_at: string | null;
  timezone: string | null;
  preferences: Record<string, unknown> | null;
  created_at: string;
  updated_at: string;
}

export interface ProfileInsert {
  id: string;
  email: string;
  full_name?: string | null;
  avatar_url?: string | null;
  date_of_birth?: string | null;
  age_tier?: AgeTier;
  is_minor_flagged?: boolean;
  minor_flagged_at?: string | null;
  minor_flag_reason?: string | null;
  behavioral_profile?: BehavioralProfile | null;
  subscription_tier?: SubscriptionTier;
  subscription_status?: SubscriptionStatus;
  stripe_customer_id?: string | null;
  stripe_subscription_id?: string | null;
  subscription_period_end?: string | null;
  is_admin?: boolean;
  messages_today?: number;
  messages_reset_at?: string;
  voice_characters_used?: number;
  voice_characters_reset_at?: string | null;
  streak_days?: number;
  last_active_at?: string | null;
  timezone?: string | null;
  preferences?: Record<string, unknown> | null;
  created_at?: string;
  updated_at?: string;
}

export interface ProfileUpdate {
  id?: string;
  email?: string;
  full_name?: string | null;
  avatar_url?: string | null;
  date_of_birth?: string | null;
  age_tier?: AgeTier;
  is_minor_flagged?: boolean;
  minor_flagged_at?: string | null;
  minor_flag_reason?: string | null;
  behavioral_profile?: BehavioralProfile | null;
  subscription_tier?: SubscriptionTier;
  subscription_status?: SubscriptionStatus;
  stripe_customer_id?: string | null;
  stripe_subscription_id?: string | null;
  subscription_period_end?: string | null;
  is_admin?: boolean;
  messages_today?: number;
  messages_reset_at?: string;
  voice_characters_used?: number;
  voice_characters_reset_at?: string | null;
  streak_days?: number;
  last_active_at?: string | null;
  timezone?: string | null;
  preferences?: Record<string, unknown> | null;
  created_at?: string;
  updated_at?: string;
}

export interface Companion {
  id: string;
  user_id: string;
  name: string;
  avatar_url: string | null;
  avatar_3d_config: Avatar3DConfig | null;
  voice_config: VoiceConfig | null;
  relationship_type: RelationshipType;
  relationship_label: string | null;
  backstory: string | null;
  personality_base: PersonalityBase | null;
  current_mood: MoodState | null;
  needs: CompanionNeeds | null;
  affection_level: number;
  trust_level: number;
  interests: string[];
  quirks: string[];
  total_messages: number;
  total_voice_minutes: number;
  total_activities: number;
  last_interaction: string | null;
  is_archived: boolean;
  created_at: string;
  updated_at: string;
}

export interface CompanionInsert {
  id?: string;
  user_id: string;
  name: string;
  avatar_url?: string | null;
  avatar_3d_config?: Avatar3DConfig | null;
  voice_config?: VoiceConfig | null;
  relationship_type: RelationshipType;
  relationship_label?: string | null;
  backstory?: string | null;
  personality_base?: PersonalityBase | null;
  current_mood?: MoodState | null;
  needs?: CompanionNeeds | null;
  affection_level?: number;
  trust_level?: number;
  interests?: string[];
  quirks?: string[];
  total_messages?: number;
  total_voice_minutes?: number;
  total_activities?: number;
  last_interaction?: string | null;
  is_archived?: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface CompanionUpdate {
  id?: string;
  user_id?: string;
  name?: string;
  avatar_url?: string | null;
  avatar_3d_config?: Avatar3DConfig | null;
  voice_config?: VoiceConfig | null;
  relationship_type?: RelationshipType;
  relationship_label?: string | null;
  backstory?: string | null;
  personality_base?: PersonalityBase | null;
  current_mood?: MoodState | null;
  needs?: CompanionNeeds | null;
  affection_level?: number;
  trust_level?: number;
  interests?: string[];
  quirks?: string[];
  total_messages?: number;
  total_voice_minutes?: number;
  total_activities?: number;
  last_interaction?: string | null;
  is_archived?: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface CompanionDNA {
  id: string;
  companion_id: string;
  communication_dialect: CommunicationDialect | null;
  emotional_patterns: EmotionalPatterns | null;
  core_traits: CoreTraits | null;
  growth_areas: GrowthAreas | null;
  learning_style_matrix: LearningStyleMatrix | null;
  humor_genome: HumorGenome | null;
  emotional_resonance_map: EmotionalResonanceMap | null;
  interest_evolution_tree: InterestEvolutionTree | null;
  memory_weighting_algorithm: MemoryWeightingAlgorithm | null;
  quirks: string[];
  created_at: string;
  updated_at: string;
}

export interface CompanionDNAInsert {
  id?: string;
  companion_id: string;
  communication_dialect?: CommunicationDialect | null;
  emotional_patterns?: EmotionalPatterns | null;
  core_traits?: CoreTraits | null;
  growth_areas?: GrowthAreas | null;
  learning_style_matrix?: LearningStyleMatrix | null;
  humor_genome?: HumorGenome | null;
  emotional_resonance_map?: EmotionalResonanceMap | null;
  interest_evolution_tree?: InterestEvolutionTree | null;
  memory_weighting_algorithm?: MemoryWeightingAlgorithm | null;
  quirks?: string[];
  created_at?: string;
  updated_at?: string;
}

export interface CompanionDNAUpdate {
  id?: string;
  companion_id?: string;
  communication_dialect?: CommunicationDialect | null;
  emotional_patterns?: EmotionalPatterns | null;
  core_traits?: CoreTraits | null;
  growth_areas?: GrowthAreas | null;
  learning_style_matrix?: LearningStyleMatrix | null;
  humor_genome?: HumorGenome | null;
  emotional_resonance_map?: EmotionalResonanceMap | null;
  interest_evolution_tree?: InterestEvolutionTree | null;
  memory_weighting_algorithm?: MemoryWeightingAlgorithm | null;
  quirks?: string[];
  created_at?: string;
  updated_at?: string;
}

export interface Conversation {
  id: string;
  companion_id: string;
  user_id: string;
  title: string | null;
  message_count: number;
  last_message_at: string | null;
  is_archived: boolean;
  created_at: string;
  updated_at: string;
}

export interface ConversationInsert {
  id?: string;
  companion_id: string;
  user_id: string;
  title?: string | null;
  message_count?: number;
  last_message_at?: string | null;
  is_archived?: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface ConversationUpdate {
  id?: string;
  companion_id?: string;
  user_id?: string;
  title?: string | null;
  message_count?: number;
  last_message_at?: string | null;
  is_archived?: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface Message {
  id: string;
  conversation_id: string;
  companion_id: string;
  user_id: string;
  role: MessageRole;
  content: string;
  content_type: ContentType;
  attachments: unknown[];
  voice_url: string | null;
  voice_duration_seconds: number | null;
  emotion_analysis: Record<string, unknown>;
  response_context: Record<string, unknown>;
  memory_triggers: string[];
  tokens_used: number;
  is_edited: boolean;
  edited_at: string | null;
  original_content: string | null;
  is_deleted: boolean;
  deleted_at: string | null;
  user_rating: number | null;
  user_feedback: string | null;
  metadata: Record<string, unknown> | null;
  created_at: string;
}

export interface MessageInsert {
  id?: string;
  conversation_id: string;
  companion_id: string;
  user_id: string;
  role: MessageRole;
  content: string;
  content_type?: ContentType;
  attachments?: unknown[];
  voice_url?: string | null;
  voice_duration_seconds?: number | null;
  emotion_analysis?: Record<string, unknown>;
  response_context?: Record<string, unknown>;
  memory_triggers?: string[];
  tokens_used?: number;
  is_edited?: boolean;
  edited_at?: string | null;
  original_content?: string | null;
  is_deleted?: boolean;
  deleted_at?: string | null;
  user_rating?: number | null;
  user_feedback?: string | null;
  metadata?: Record<string, unknown> | null;
  created_at?: string;
}

export interface MessageUpdate {
  id?: string;
  conversation_id?: string;
  companion_id?: string;
  user_id?: string;
  role?: MessageRole;
  content?: string;
  content_type?: ContentType;
  attachments?: unknown[];
  voice_url?: string | null;
  voice_duration_seconds?: number | null;
  emotion_analysis?: Record<string, unknown>;
  response_context?: Record<string, unknown>;
  memory_triggers?: string[];
  tokens_used?: number;
  is_edited?: boolean;
  edited_at?: string | null;
  original_content?: string | null;
  is_deleted?: boolean;
  deleted_at?: string | null;
  user_rating?: number | null;
  user_feedback?: string | null;
  metadata?: Record<string, unknown> | null;
  created_at?: string;
}

export interface Memory {
  id: string;
  companion_id: string;
  user_id: string;
  title: string | null;
  content: string;
  category_id: string | null;
  embedding: number[] | null;
  importance_score: number;
  emotional_context: string | null;
  is_core_memory: boolean;
  is_pinned: boolean;
  is_core_identity: boolean;
  source_message_id: string | null;
  source_type: string | null;
  source: string | null;
  recalled_count: number;
  access_count: number;
  last_recalled_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface MemoryInsert {
  id?: string;
  companion_id: string;
  user_id: string;
  title?: string | null;
  content: string;
  category_id?: string | null;
  embedding?: number[] | null;
  importance_score?: number;
  emotional_context?: string | null;
  is_core_memory?: boolean;
  is_pinned?: boolean;
  is_core_identity?: boolean;
  source_message_id?: string | null;
  source_type?: string | null;
  source?: string | null;
  recalled_count?: number;
  access_count?: number;
  last_recalled_at?: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface MemoryUpdate {
  id?: string;
  companion_id?: string;
  user_id?: string;
  title?: string | null;
  content?: string;
  category_id?: string | null;
  embedding?: number[] | null;
  importance_score?: number;
  emotional_context?: string | null;
  is_core_memory?: boolean;
  is_pinned?: boolean;
  is_core_identity?: boolean;
  source_message_id?: string | null;
  source_type?: string | null;
  source?: string | null;
  recalled_count?: number;
  access_count?: number;
  last_recalled_at?: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface MemoryCategoryRow {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  icon: string | null;
  color: string | null;
  created_at: string;
}

export interface MemoryCategoryInsert {
  id?: string;
  name: string;
  slug: string;
  description?: string | null;
  icon?: string | null;
  color?: string | null;
  created_at?: string;
}

export interface MemoryCategoryUpdate {
  id?: string;
  name?: string;
  slug?: string;
  description?: string | null;
  icon?: string | null;
  color?: string | null;
  created_at?: string;
}

export interface LifeEvent {
  id: string;
  companion_id: string;
  user_id: string;
  event_type: EventType;
  title: string;
  description: string | null;
  mood_before: MoodState | null;
  mood_after: MoodState | null;
  scheduled_at: string | null;
  completed_at: string | null;
  should_notify_user: boolean;
  notification_message: string | null;
  notification_sent: boolean;
  metadata: Record<string, unknown> | null;
  created_at: string;
}

export interface LifeEventInsert {
  id?: string;
  companion_id: string;
  user_id: string;
  event_type: EventType;
  title: string;
  description?: string | null;
  mood_before?: MoodState | null;
  mood_after?: MoodState | null;
  scheduled_at?: string | null;
  completed_at?: string | null;
  should_notify_user?: boolean;
  notification_message?: string | null;
  notification_sent?: boolean;
  metadata?: Record<string, unknown> | null;
  created_at?: string;
}

export interface LifeEventUpdate {
  id?: string;
  companion_id?: string;
  user_id?: string;
  event_type?: EventType;
  title?: string;
  description?: string | null;
  mood_before?: MoodState | null;
  mood_after?: MoodState | null;
  scheduled_at?: string | null;
  completed_at?: string | null;
  should_notify_user?: boolean;
  notification_message?: string | null;
  notification_sent?: boolean;
  metadata?: Record<string, unknown> | null;
  created_at?: string;
}

export interface Activity {
  id: string;
  name: string;
  description: string | null;
  activity_type: ActivityType;
  icon: string | null;
  min_tier: SubscriptionTier;
  needs_fulfillment: Partial<CompanionNeeds> | null;
  duration_minutes: number;
  is_multiplayer: boolean;
  is_active: boolean;
  created_at: string;
}

export interface ActivityInsert {
  id?: string;
  name: string;
  description?: string | null;
  activity_type: ActivityType;
  icon?: string | null;
  min_tier?: SubscriptionTier;
  needs_fulfillment?: Partial<CompanionNeeds> | null;
  duration_minutes?: number;
  is_multiplayer?: boolean;
  is_active?: boolean;
  created_at?: string;
}

export interface ActivityUpdate {
  id?: string;
  name?: string;
  description?: string | null;
  activity_type?: ActivityType;
  icon?: string | null;
  min_tier?: SubscriptionTier;
  needs_fulfillment?: Partial<CompanionNeeds> | null;
  duration_minutes?: number;
  is_multiplayer?: boolean;
  is_active?: boolean;
  created_at?: string;
}

export interface ActivitySession {
  id: string;
  activity_id: string;
  companion_id: string;
  user_id: string;
  started_at: string;
  ended_at: string | null;
  score: number | null;
  metadata: Record<string, unknown> | null;
  created_at: string;
}

export interface ActivitySessionInsert {
  id?: string;
  activity_id: string;
  companion_id: string;
  user_id: string;
  started_at?: string;
  ended_at?: string | null;
  score?: number | null;
  metadata?: Record<string, unknown> | null;
  created_at?: string;
}

export interface ActivitySessionUpdate {
  id?: string;
  activity_id?: string;
  companion_id?: string;
  user_id?: string;
  started_at?: string;
  ended_at?: string | null;
  score?: number | null;
  metadata?: Record<string, unknown> | null;
  created_at?: string;
}

export interface CrisisLog {
  id: string;
  user_id: string;
  companion_id: string | null;
  conversation_id: string | null;
  message_excerpt: string | null;
  crisis_type: CrisisType;
  severity: CrisisSeverity;
  keywords_matched: string[];
  response_provided: string | null;
  reviewed: boolean;
  reviewed_by: string | null;
  reviewed_at: string | null;
  notes: string | null;
  created_at: string;
}

export interface CrisisLogInsert {
  id?: string;
  user_id: string;
  companion_id?: string | null;
  conversation_id?: string | null;
  message_excerpt?: string | null;
  crisis_type: CrisisType;
  severity: CrisisSeverity;
  keywords_matched?: string[];
  response_provided?: string | null;
  reviewed?: boolean;
  reviewed_by?: string | null;
  reviewed_at?: string | null;
  notes?: string | null;
  created_at?: string;
}

export interface CrisisLogUpdate {
  id?: string;
  user_id?: string;
  companion_id?: string | null;
  conversation_id?: string | null;
  message_excerpt?: string | null;
  crisis_type?: CrisisType;
  severity?: CrisisSeverity;
  keywords_matched?: string[];
  response_provided?: string | null;
  reviewed?: boolean;
  reviewed_by?: string | null;
  reviewed_at?: string | null;
  notes?: string | null;
  created_at?: string;
}

export interface BehavioralDetectionLog {
  id: string;
  user_id: string;
  message_excerpt: string | null;
  triggers: string[];
  categories: string[];
  confidence: number;
  detected_age: number | null;
  resulted_in_flag: boolean;
  created_at: string;
}

export interface BehavioralDetectionLogInsert {
  id?: string;
  user_id: string;
  message_excerpt?: string | null;
  triggers?: string[];
  categories?: string[];
  confidence?: number;
  detected_age?: number | null;
  resulted_in_flag?: boolean;
  created_at?: string;
}

export interface BehavioralDetectionLogUpdate {
  id?: string;
  user_id?: string;
  message_excerpt?: string | null;
  triggers?: string[];
  categories?: string[];
  confidence?: number;
  detected_age?: number | null;
  resulted_in_flag?: boolean;
  created_at?: string;
}

export interface RelationshipMilestone {
  id: string;
  companion_id: string;
  user_id: string;
  milestone_type: string;
  title: string;
  description: string | null;
  affection_at_time: number;
  trust_at_time: number;
  achieved_at: string;
  created_at: string;
}

export interface RelationshipMilestoneInsert {
  id?: string;
  companion_id: string;
  user_id: string;
  milestone_type: string;
  title: string;
  description?: string | null;
  affection_at_time?: number;
  trust_at_time?: number;
  achieved_at?: string;
  created_at?: string;
}

export interface RelationshipMilestoneUpdate {
  id?: string;
  companion_id?: string;
  user_id?: string;
  milestone_type?: string;
  title?: string;
  description?: string | null;
  affection_at_time?: number;
  trust_at_time?: number;
  achieved_at?: string;
  created_at?: string;
}

export interface UserAchievement {
  id: string;
  user_id: string;
  achievement_id: string;
  unlocked_at: string;
  metadata: Record<string, unknown> | null;
  created_at: string;
}

export interface UserAchievementInsert {
  id?: string;
  user_id: string;
  achievement_id: string;
  unlocked_at?: string;
  metadata?: Record<string, unknown> | null;
  created_at?: string;
}

export interface UserAchievementUpdate {
  id?: string;
  user_id?: string;
  achievement_id?: string;
  unlocked_at?: string;
  metadata?: Record<string, unknown> | null;
  created_at?: string;
}

export interface DataExport {
  id: string;
  user_id: string;
  export_type: string;
  status: string;
  file_url: string | null;
  expires_at: string;
  created_at: string;
}

export interface DataExportInsert {
  id?: string;
  user_id: string;
  export_type: string;
  status?: string;
  file_url?: string | null;
  expires_at?: string;
  created_at?: string;
}

export interface DataExportUpdate {
  id?: string;
  user_id?: string;
  export_type?: string;
  status?: string;
  file_url?: string | null;
  expires_at?: string;
  created_at?: string;
}

export interface AuditLog {
  id: string;
  user_id: string;
  action: string;
  details: Record<string, unknown> | null;
  ip_address: string | null;
  user_agent: string | null;
  created_at: string;
}

export interface AuditLogInsert {
  id?: string;
  user_id: string;
  action: string;
  details?: Record<string, unknown> | null;
  ip_address?: string | null;
  user_agent?: string | null;
  created_at?: string;
}

export interface AuditLogUpdate {
  id?: string;
  user_id?: string;
  action?: string;
  details?: Record<string, unknown> | null;
  ip_address?: string | null;
  user_agent?: string | null;
  created_at?: string;
}

export interface MemoryAccessLog {
  id: string;
  memory_id: string | null;
  companion_id: string;
  access_type: string;
  context: Record<string, unknown> | null;
  created_at: string;
}

export interface MemoryAccessLogInsert {
  id?: string;
  memory_id?: string | null;
  companion_id: string;
  access_type: string;
  context?: Record<string, unknown> | null;
  created_at?: string;
}

export interface MemoryAccessLogUpdate {
  id?: string;
  memory_id?: string | null;
  companion_id?: string;
  access_type?: string;
  context?: Record<string, unknown> | null;
  created_at?: string;
}

// ============================================================
// Helper Types for Queries
// ============================================================

/**
 * Companion with its DNA joined
 */
export interface CompanionWithDNA extends Companion {
  companion_dna: CompanionDNA[] | null;
}

/**
 * Message with conversation and companion
 */
export interface MessageWithContext extends Message {
  conversations?: Conversation & {
    companions?: Companion;
  };
}

/**
 * Memory with category
 */
export interface MemoryWithCategory extends Memory {
  memory_categories?: Pick<MemoryCategoryRow, 'name' | 'icon' | 'color'> | null;
}

/**
 * Life event with companion info
 */
export interface LifeEventWithCompanion extends LifeEvent {
  companions?: Companion;
}
